#include <iostream>

using namespace std; 

int main()
{
    cout << "Hello World\n"; // Outputs "Hello World" with a line end
}