#include "encryption.ih"

char Encryption::sub(char a, char b)
{
    return a - b;
}