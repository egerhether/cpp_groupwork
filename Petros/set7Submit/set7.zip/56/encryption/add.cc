#include "encryption.ih"

char Encryption::add(char a, char b)
{
    return a + b;
}