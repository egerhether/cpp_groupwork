#include "data.ih"

Data::Data(string word)
:
    u_word(word)
{
    u_field = TEXT;
}