#include "main.ih"

int main()
{
    Numbers numbers(10);
    numbers.write(cout);
}
