#include "main.ih"

int main() 
{
    cout << now << '\n';
}

