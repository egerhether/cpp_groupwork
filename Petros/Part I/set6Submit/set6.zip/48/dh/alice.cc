#include "dh.ih"

void DH::alice(string const &socket, string const &bobPubFname)
{
    cout << "This is Alice! How are you?\n";
}