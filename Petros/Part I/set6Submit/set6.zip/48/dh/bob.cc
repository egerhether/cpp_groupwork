#include "dh.ih"

void DH::bob(string const &bobPubFname, string const &alicePubFname)
{
    cout << "This is bob!\n";
}