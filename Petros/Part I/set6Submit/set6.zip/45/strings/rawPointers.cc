#include "strings.ih"

string **Strings::rawPointers(size_t nr)
{
    string **tmp = new string *[nr];
    return tmp;
}