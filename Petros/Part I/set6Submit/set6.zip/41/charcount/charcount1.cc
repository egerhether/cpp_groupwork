#include "charcount.ih"

CharCount::CharCount()
:
    d_CharInfo { new Char[8], 0 }
{}
