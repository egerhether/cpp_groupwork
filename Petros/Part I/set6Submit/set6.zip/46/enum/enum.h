#ifndef INCLUDED_ENUM_
#define INCLUDED_ENUM_


enum Token
{
    QUIT,
    CHAR,
    INT,
    DOUBLE,
    IDENT,
    ERROR,
};
        
#endif
