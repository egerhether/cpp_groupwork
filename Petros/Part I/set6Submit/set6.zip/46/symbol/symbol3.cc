#include "symbol.ih"

Symbol::Symbol(std::string name, double value)
:
    d_name(name),
    d_Value(value)
{}
