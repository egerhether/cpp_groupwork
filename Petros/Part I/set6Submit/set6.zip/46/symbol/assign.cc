#include "symbol.ih"

void Symbol::assign(Value const &value)
{
    d_Value = value;
}
