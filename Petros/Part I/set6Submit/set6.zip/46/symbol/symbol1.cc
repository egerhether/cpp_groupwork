#include "symbol.ih"

Symbol::Symbol()
{}
