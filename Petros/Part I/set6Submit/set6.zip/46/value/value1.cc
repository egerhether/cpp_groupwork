#include "value.ih"

Value::Value()
:
    d_value(0),
    d_type(Token::INT)
{}
