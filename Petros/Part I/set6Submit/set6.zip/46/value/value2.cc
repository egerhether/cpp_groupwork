#include "value.ih"

Value::Value(int value)
:
    d_value(value),
    d_type(Token::INT)
{}
