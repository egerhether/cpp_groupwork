#include "charcount.ih"

CharCount::CharCount()
{
    d_CharInfo.ptr = new Char[8];
    d_CharInfo.nCharObj = 0;
}
