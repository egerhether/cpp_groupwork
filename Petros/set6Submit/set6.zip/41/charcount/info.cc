#include "charcount.ih"

const CharCount::CharInfo &CharCount::info() const
{
    return d_CharInfo;
}
