#include "symtab.ih"

Symtab::~Symtab()
{
    destroy();
}
