#ifndef FINDCASE_H_
#define FINDCASE_H_

#include <iostream>
#include <string>

size_t findcase(std::string const &str, std::string const &target, size_t offset);
std::string str_tolower(std::string str);

#endif