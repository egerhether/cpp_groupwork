#ifndef SUM_HH
#define SUM_HH

bool checkDot(int argc, char *argv[]);
double sum (int argc, char *argv[], double dummy);
int sum (int argc, char *argv[], int dummy);

#endif
