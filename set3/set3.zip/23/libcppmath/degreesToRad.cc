#include "cppmath.ih"

double degreeToRad(size_t degrees)
{
    double doubDegrees = degrees;
    return degreeToRad(doubDegrees);
}
