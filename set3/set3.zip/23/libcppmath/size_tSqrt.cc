#include "cppmath.ih"

size_t sqrt(size_t square)
{
    unsigned long long toRoot = square;
    return sqrt(toRoot);
}
