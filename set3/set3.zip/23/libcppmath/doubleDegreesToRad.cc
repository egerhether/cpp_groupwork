#include "cppmath.ih"

double degreeToRad(double degrees)
{
    double rad = degrees * M_PI/180;
    return rad;
}
